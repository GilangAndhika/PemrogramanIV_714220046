package com.example.dio_contact

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
