package com.example.uts_714220046

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
